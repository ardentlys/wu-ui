<template>
	<view class="wu-calendar-item__weeks-box" :class="{
		'wu-calendar-item--disable': weeks.disable,
		}" :style="[calendarItemStyle]" @click="choiceDate(weeks)">
		<view class="wu-calendar-item__weeks-box-item">
			<text v-if="selected && weeks.extraInfo" class="wu-calendar-item__weeks-box-circle" :style="[{backgroundColor: this.weeks.extraInfo.infoColor}]"></text>
			<text class="wu-calendar-item__weeks-box-text" :class="{
				'wu-calendar-item--disable': weeks.disable,
				}" :style="[calendarItemStyle]">{{weeks.date}}</text>
			<text v-if="!lunar && !weeks.extraInfo && weeks.isDay" class="wu-calendar-item__weeks-lunar-text" :class="{
				}" :style="[calendarItemStyle]">{{todayText}}</text>
			<text v-if="lunar && !weeks.extraInfo" class="wu-calendar-item__weeks-lunar-text" :class="{
				'wu-calendar-item--disable': weeks.disable,
				}" :style="[calendarItemStyle]">{{dayText}}</text>
			<text v-if="weeks.extraInfo && weeks.extraInfo.info" class="wu-calendar-item__weeks-lunar-text" :class="{
				'wu-calendar-item--extra': weeks.extraInfo.info,
				'wu-calendar-item--disable': weeks.disable,
				}" :style="[{color: this.weeks.extraInfo.infoColor}, calendarItemStyle]">{{weeks.extraInfo.info}}</text>
		</view>
	</view>
</template>

<script>
	import mpMixin from '@/uni_modules/wu-ui-tools/libs/mixin/mpMixin.js';
	import mixin from '@/uni_modules/wu-ui-tools/libs/mixin/mixin.js';
	import props from './props.js';

	import {
		initVueI18n
	} from '@dcloudio/uni-i18n'
	import i18nMessages from '../i18n/index.js'
	const {
		t
	} = initVueI18n(i18nMessages)

	export default {
		emits: ['change'],
		mixins: [mpMixin, mixin, props],
		computed: {
			todayText() {
				return t("wu-calender.today")
			},
			calendarItemStyle() {
				let style = {};
				let color = this.$w.Color.gradient(this.color, this.$w.Color.isLight(this.color) ? '#000' : '#fff', 100)[6]
				// 有顺序别乱动
				if (this.weeks.multiple) {
					style = {
						backgroundColor: this.$w.Color.gradient(this.color, '#fff', 100)[80],
						color
					}
				};
				if (this.weeks.isDay) {
					style.color = color;
				}
				if (this.weeks.beforeMultiple || this.weeks.afterMultiple || (this.calendar.fullDate === this.weeks
						.fullDate && !this.weeks.isDay) || (this.calendar.fullDate === this.weeks.fullDate && this.weeks
						.isDay)) {
					style = {
						backgroundColor: this.color,
						color: '#fff'
					}
				}
				return style;
			},
			dayText() {
				let text = '';
				if (this.weeks.beforeMultiple) {
					text = this.startText
				} else if (this.weeks.afterMultiple) {
					text = this.endText
				} else if (this.weeks.isDay) {
					text = this.todayText
				} else if (this.weeks.lunar.IDayCn === '初一') {
					text = this.weeks.lunar.IMonthCn
				} else {
					text = this.weeks.lunar.IDayCn
				}

				return text
			}
		},
		methods: {
			choiceDate(weeks) {
				this.$emit('change', weeks)
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import '@/uni_modules/wu-ui-tools/theme.scss';
	$wu-font-size-base: 14px;
	$wu-text-color: #333;
	$wu-font-size-sm: 12px;
	$wu-color-error: #e43d33;
	$wu-opacity-disabled: 0.3;
	$wu-text-color-disable: #c0c0c0;

	.wu-calendar-item__weeks-box {
		flex: 1;
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	.wu-calendar-item__weeks-box-text {
		font-size: $wu-font-size-base;
		color: $wu-text-color;
	}

	.wu-calendar-item__weeks-lunar-text {
		font-size: $wu-font-size-sm;
		color: $wu-text-color;
	}

	.wu-calendar-item__weeks-box-item {
		position: relative;
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
		justify-content: center;
		align-items: center;
		width: 100rpx;
		height: 100rpx;
	}

	.wu-calendar-item__weeks-box-circle {
		position: absolute;
		top: 5px;
		right: 5px;
		width: 8px;
		height: 8px;
		border-radius: 8px;
		background-color: $wu-color-error;

	}

	.wu-calendar-item--disable {
		background-color: rgba(249, 249, 249, $wu-opacity-disabled);
		color: $wu-text-color-disable;
	}

	.wu-calendar-item--extra {
		color: $wu-color-error;
		opacity: 0.8;
	}

	.wu-calendar-item--checked {
		color: #fff;
	}
</style>