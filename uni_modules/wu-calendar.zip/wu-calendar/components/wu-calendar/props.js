export default {
	props: {
		// 自定义当前时间，默认为今天
		date: {
			type: String,
			default: ''
		},
		// 主题色
		color: {
			type: String,
			default: '#3c9cff'
		},
		// 	mode=range时，第一个日期底部的提示文字
		startText: {
			type: String,
			default: '开始'
		},
		// mode=range时，最后一个日期底部的提示文字
		endText: {
			type: String,
			default: '结束'
		},
		// 打点，期待格式[{date: '2019-06-27', info: '签到', data: { custom: '自定义信息', name: '自定义消息头',xxx:xxx... }}]
		selected: {
			type: Array,
			default () {
				return []
			}
		},
		// 是否显示农历
		lunar: {
			type: Boolean,
			default: false
		},
		// 日期选择范围-开始日期
		startDate: {
			type: String,
			default: ''
		},
		// 日期选择范围-结束日期
		endDate: {
			type: String,
			default: ''
		},
		// 范围选择
		range: {
			type: Boolean,
			default: false
		},
		// 插入模式,可选值，ture：插入模式；false：弹窗模式；默认为插入模式
		insert: {
			type: Boolean,
			default: true
		},
		// 是否显示月份为背景
		showMonth: {
			type: Boolean,
			default: true
		},
		// 弹窗模式是否清空上次选择内容
		clearDate: {
			type: Boolean,
			default: true
		},
		...uni.$w?.props?.calendar
	}
}