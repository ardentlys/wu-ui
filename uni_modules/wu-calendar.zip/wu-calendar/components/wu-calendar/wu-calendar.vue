<template>
	<view class="wu-calendar">
		<view v-if="!insert&&show" class="wu-calendar__mask" :class="{'wu-calendar--mask-show':aniMaskShow}"
			@click="clean"></view>
		<view v-if="insert || show" class="wu-calendar__content"
			:class="{'wu-calendar--fixed':!insert,'wu-calendar--ani-show':aniMaskShow}">
			<view v-if="!insert" class="wu-calendar__header wu-calendar--fixed-top">
				<view class="wu-calendar__header-btn-box" @click="close">
					<text class="wu-calendar__header-text wu-calendar--fixed-width">{{cancelText}}</text>
				</view>
				<view class="wu-calendar__header-btn-box" @click="confirm">
					<text class="wu-calendar__header-text wu-calendar--fixed-width">{{okText}}</text>
				</view>
			</view>
			<view class="wu-calendar__header">
				<view class="wu-calendar__header-btn-box" @click.stop="pre">
					<view class="wu-calendar__header-btn wu-calendar--left"></view>
				</view>
				<picker mode="date" :value="date" fields="month" @change="bindDateChange">
					<text class="wu-calendar__header-text">{{ (nowDate.year||'') +' / '+( nowDate.month||'')}}</text>
				</picker>
				<view class="wu-calendar__header-btn-box" @click.stop="next">
					<view class="wu-calendar__header-btn wu-calendar--right"></view>
				</view>
				<text class="wu-calendar__backtoday" @click="backToday">{{todayText}}</text>
			</view>
			<view class="wu-calendar__box">
				<view v-if="showMonth" class="wu-calendar__box-bg">
					<text class="wu-calendar__box-bg-text">{{nowDate.month}}</text>
				</view>
				<view class="wu-calendar__weeks">
					<view class="wu-calendar__weeks-day">
						<text class="wu-calendar__weeks-day-text">{{SUNText}}</text>
					</view>
					<view class="wu-calendar__weeks-day">
						<text class="wu-calendar__weeks-day-text">{{monText}}</text>
					</view>
					<view class="wu-calendar__weeks-day">
						<text class="wu-calendar__weeks-day-text">{{TUEText}}</text>
					</view>
					<view class="wu-calendar__weeks-day">
						<text class="wu-calendar__weeks-day-text">{{WEDText}}</text>
					</view>
					<view class="wu-calendar__weeks-day">
						<text class="wu-calendar__weeks-day-text">{{THUText}}</text>
					</view>
					<view class="wu-calendar__weeks-day">
						<text class="wu-calendar__weeks-day-text">{{FRIText}}</text>
					</view>
					<view class="wu-calendar__weeks-day">
						<text class="wu-calendar__weeks-day-text">{{SATText}}</text>
					</view>
				</view>
				<swiper :duration="1000" circular style="height: 500rpx" @change="swiperChange">
					<swiper-item>
						<view class="wu-calendar__weeks" v-for="(item,weekIndex) in weeks" :key="weekIndex">
							<view class="wu-calendar__weeks-item" v-for="(weeks,weeksIndex) in item" :key="weeksIndex">
								<wu-calendar-item class="wu-calendar-item--hook" :weeks="weeks" :calendar="calendar"
									:selected="selected" :lunar="lunar" @change="choiceDate"
									:color="color"></wu-calendar-item>
							</view>
						</view>
					</swiper-item>
					<swiper-item>
						<view class="wu-calendar__weeks" v-for="(item,weekIndex) in weeks" :key="weekIndex">
							<view class="wu-calendar__weeks-item" v-for="(weeks,weeksIndex) in item" :key="weeksIndex">
								<wu-calendar-item class="wu-calendar-item--hook" :weeks="weeks" :calendar="calendar"
									:selected="selected" :lunar="lunar" @change="choiceDate"
									:color="color"></wu-calendar-item>
							</view>
						</view>
					</swiper-item>
					<swiper-item>
						<view class="wu-calendar__weeks" v-for="(item,weekIndex) in weeks" :key="weekIndex">
							<view class="wu-calendar__weeks-item" v-for="(weeks,weeksIndex) in item" :key="weeksIndex">
								<wu-calendar-item class="wu-calendar-item--hook" :weeks="weeks" :calendar="calendar"
									:selected="selected" :lunar="lunar" @change="choiceDate"
									:color="color"></wu-calendar-item>
							</view>
						</view>
					</swiper-item>
				</swiper>
			</view>
		</view>
	</view>
</template>

<script>
	import Calendar from './util.js';
	import mpMixin from '@/uni_modules/wu-ui-tools/libs/mixin/mpMixin.js';
	import mixin from '@/uni_modules/wu-ui-tools/libs/mixin/mixin.js';
	import props from './props.js';

	import {
		initVueI18n
	} from '@dcloudio/uni-i18n'
	import i18nMessages from '../i18n/index.js'
	const {
		t
	} = initVueI18n(i18nMessages)

	/**
	 * Calendar 日历
	 * @description 日历组件可以查看日期，选择任意范围内的日期，打点操作。常用场景如：酒店日期预订、火车机票选择购买日期、上下班打卡等
	 * @tutorial https://wu.geeks.ink/zh-CN/components/calendar.html
	 * @property {String} date 自定义当前时间，默认为今天
	 * @property {String} color 主题色(默认#3c9cff)
	 * @property {String} startText mode=range时，第一个日期底部的提示文字
	 * @property {String} endText mode=range时，最后一个日期底部的提示文字
	 * @property {Boolean} lunar 显示农历
	 * @property {String} startDate 日期选择范围-开始日期
	 * @property {String} endDate 日期选择范围-结束日期
	 * @property {Boolean} range 范围选择
	 * @property {Boolean} insert = [true|false] 插入模式,默认为false
	 * 	@value true 弹窗模式
	 * 	@value false 插入模式
	 * @property {Boolean} clearDate = [true|false] 弹窗模式是否清空上次选择内容
	 * @property {Array} selected 打点，期待格式[{date: '2019-06-27', info: '签到', data: { custom: '自定义信息', name: '自定义消息头',xxx:xxx... }}]
	 * @property {Boolean} showMonth 是否选择月份为背景
	 * @event {Function} change 日期改变，`insert :ture` 时生效
	 * @event {Function} confirm 确认选择`insert :false` 时生效
	 * @event {Function} monthSwitch 切换月份时触发
	 * @example <wu-calendar :insert="true":lunar="true" :start-date="'2019-3-2'":end-date="'2019-5-20'"@change="change" />
	 */
	export default {
		mixins: [mpMixin, mixin, props],
		emits: ['close', 'confirm', 'change', 'monthSwitch'],
		data() {
			return {
				show: false,
				weeks: [],
				calendar: {},
				nowDate: '',
				aniMaskShow: false,
				swiperCurrent: 0
			}
		},
		computed: {
			/**
			 * for i18n
			 */

			okText() {
				return t("wu-calender.ok")
			},
			cancelText() {
				return t("wu-calender.cancel")
			},
			todayText() {
				return t("wu-calender.today")
			},
			monText() {
				return t("wu-calender.MON")
			},
			TUEText() {
				return t("wu-calender.TUE")
			},
			WEDText() {
				return t("wu-calender.WED")
			},
			THUText() {
				return t("wu-calender.THU")
			},
			FRIText() {
				return t("wu-calender.FRI")
			},
			SATText() {
				return t("wu-calender.SAT")
			},
			SUNText() {
				return t("wu-calender.SUN")
			},
		},
		watch: {
			date(newVal) {
				// this.cale.setDate(newVal)
				this.init(newVal)
			},
			startDate(val) {
				this.cale.resetSatrtDate(val)
				this.cale.setDate(this.nowDate.fullDate)
				this.weeks = this.cale.weeks
			},
			endDate(val) {
				this.cale.resetEndDate(val)
				this.cale.setDate(this.nowDate.fullDate)
				this.weeks = this.cale.weeks
			},
			selected(newVal) {
				this.cale.setSelectInfo(this.nowDate.fullDate, newVal)
				this.weeks = this.cale.weeks
			},
		},
		created() {
			this.cale = new Calendar({
				selected: this.selected,
				startDate: this.startDate,
				endDate: this.endDate,
				range: this.range,
			})
			this.init(this.date)
		},
		methods: {
			// 取消穿透
			clean() {},
			bindDateChange(e) {
				const value = e.detail.value + '-1'
				this.setDate(value)

				const {
					year,
					month
				} = this.cale.getDate(value)
				this.$emit('monthSwitch', {
					year,
					month
				})
			},
			/**
			 * 初始化日期显示
			 * @param {Object} date
			 */
			init(date) {
				this.cale.setDate(date);
				this.cale.setMultiple(date || this.cale.date.fullDate);
				this.weeks = this.cale.weeks;
				this.nowDate = this.calendar = this.cale.getInfo(date);
			},
			/**
			 * 打开日历弹窗
			 */
			open() {
				// 弹窗模式并且清理数据
				if (this.clearDate && !this.insert) {
					this.cale.cleanMultipleStatus()
					// this.cale.setDate(this.date)
					this.init(this.date)
				}
				this.show = true
				this.$nextTick(() => {
					setTimeout(() => {
						this.aniMaskShow = true
					}, 50)
				})
			},
			/**
			 * 关闭日历弹窗
			 */
			close() {
				this.aniMaskShow = false
				this.$nextTick(() => {
					setTimeout(() => {
						this.show = false
						this.$emit('close')
					}, 300)
				})
			},
			/**
			 * 确认按钮
			 */
			confirm() {
				this.setEmit('confirm')
				this.close()
			},
			/**
			 * 变化触发
			 */
			change() {
				if (!this.insert) return
				this.setEmit('change')
			},
			/**
			 * 选择月份触发
			 */
			monthSwitch() {
				let {
					year,
					month
				} = this.nowDate
				this.$emit('monthSwitch', {
					year,
					month: Number(month)
				})
			},
			/**
			 * 派发事件
			 * @param {Object} name
			 */
			setEmit(name) {
				let {
					year,
					month,
					date,
					fullDate,
					lunar,
					extraInfo
				} = this.calendar
				this.$emit(name, {
					range: this.cale.multipleStatus,
					year,
					month,
					date,
					fulldate: fullDate,
					lunar,
					extraInfo: extraInfo || {}
				})
			},
			/**
			 * 选择天触发
			 * @param {Object} weeks
			 */
			choiceDate(weeks) {
				if (weeks.disable) return
				this.calendar = weeks;
				// 设置多选
				this.cale.setMultiple(this.calendar.fullDate);
				this.weeks = this.cale.weeks;
				this.change();
			},
			/**
			 * 回到今天
			 */
			backToday() {
				const nowYearMonth = `${this.nowDate.year}-${this.nowDate.month}`
				const date = this.cale.getDate(new Date())
				const todayYearMonth = `${date.year}-${date.month}`

				if (nowYearMonth !== todayYearMonth) {
					this.monthSwitch()
				}

				this.init(date.fullDate)
				this.change()
			},
			/**
			 * 上个月
			 */
			pre() {
				const preDate = this.cale.getDate(this.nowDate.fullDate, -1, 'month').fullDate
				this.setDate(preDate)
				this.monthSwitch()
			},
			/**
			 * 下个月
			 */
			next() {
				const nextDate = this.cale.getDate(this.nowDate.fullDate, +1, 'month').fullDate
				this.setDate(nextDate)
				this.monthSwitch()
			},
			/**
			 * 设置日期
			 * @param {Object} date
			 */
			setDate(date) {
				this.cale.setDate(date)
				this.weeks = this.cale.weeks
				this.nowDate = this.cale.getInfo(date)
			},
			/**
			 * 滑动切换日期
			 */
			swiperChange(e) {
				
			}
		}
	}
</script>

<style lang="scss" scoped>
	$wu-bg-color-mask: rgba($color: #000000, $alpha: 0.4);
	$wu-border-color: #EDEDED;
	$wu-text-color: #333;
	$wu-bg-color-hover: #f1f1f1;
	$wu-font-size-base: 14px;
	$wu-text-color-placeholder: #808080;
	$wu-color-subtitle: #555555;
	$wu-text-color-grey: #999;

	.wu-calendar {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
	}

	.wu-calendar__mask {
		position: fixed;
		bottom: 0;
		top: 0;
		left: 0;
		right: 0;
		background-color: $wu-bg-color-mask;
		transition-property: opacity;
		transition-duration: 0.3s;
		opacity: 0;
		/* #ifndef APP-NVUE */
		z-index: 99;
		/* #endif */
	}

	.wu-calendar--mask-show {
		opacity: 1
	}

	.wu-calendar--fixed {
		position: fixed;
		/* #ifdef APP-NVUE */
		bottom: 0;
		/* #endif */
		left: 0;
		right: 0;
		transition-property: transform;
		transition-duration: 0.3s;
		transform: translateY(460px);
		/* #ifndef APP-NVUE */
		bottom: calc(var(--window-bottom));
		z-index: 99;
		/* #endif */
	}

	.wu-calendar--ani-show {
		transform: translateY(0);
	}

	.wu-calendar__content {
		background-color: #fff;
	}

	.wu-calendar__header {
		position: relative;
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
		justify-content: center;
		align-items: center;
		height: 50px;
		border-bottom-color: $wu-border-color;
		border-bottom-style: solid;
		border-bottom-width: 1px;
	}

	.wu-calendar--fixed-top {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
		justify-content: space-between;
		border-top-color: $wu-border-color;
		border-top-style: solid;
		border-top-width: 1px;
	}

	.wu-calendar--fixed-width {
		width: 50px;
	}

	.wu-calendar__backtoday {
		position: absolute;
		right: 0;
		top: 25rpx;
		padding: 0 5px;
		padding-left: 10px;
		height: 25px;
		line-height: 25px;
		font-size: 12px;
		border-top-left-radius: 25px;
		border-bottom-left-radius: 25px;
		color: $wu-text-color;
		background-color: $wu-bg-color-hover;
	}

	.wu-calendar__header-text {
		text-align: center;
		width: 100px;
		font-size: $wu-font-size-base;
		color: $wu-text-color;
	}

	.wu-calendar__header-btn-box {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
		align-items: center;
		justify-content: center;
		width: 50px;
		height: 50px;
	}

	.wu-calendar__header-btn {
		width: 10px;
		height: 10px;
		border-left-color: $wu-text-color-placeholder;
		border-left-style: solid;
		border-left-width: 2px;
		border-top-color: $wu-color-subtitle;
		border-top-style: solid;
		border-top-width: 2px;
	}

	.wu-calendar--left {
		transform: rotate(-45deg);
	}

	.wu-calendar--right {
		transform: rotate(135deg);
	}


	.wu-calendar__weeks {
		position: relative;
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
	}

	.wu-calendar__weeks-item {
		flex: 1;
	}

	.wu-calendar__weeks-day {
		flex: 1;
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
		justify-content: center;
		align-items: center;
		height: 45px;
		border-bottom-color: #F5F5F5;
		border-bottom-style: solid;
		border-bottom-width: 1px;
	}

	.wu-calendar__weeks-day-text {
		font-size: 14px;
	}

	.wu-calendar__box {
		position: relative;
	}

	.wu-calendar__box-bg {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		justify-content: center;
		align-items: center;
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
	}

	.wu-calendar__box-bg-text {
		font-size: 200px;
		font-weight: bold;
		color: $wu-text-color-grey;
		opacity: 0.1;
		text-align: center;
		/* #ifndef APP-NVUE */
		line-height: 1;
		/* #endif */
	}
</style>